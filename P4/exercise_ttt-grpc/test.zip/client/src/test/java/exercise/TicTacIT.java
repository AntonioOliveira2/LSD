package exercise;

import static org.junit.jupiter.api.*;

public class TicTacIT {

}
